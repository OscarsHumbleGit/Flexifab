                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2690732
Duet3D PanelDue Mount by Amilious is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

<h1><u>PanelDue Mount</u></h1>

<br>
<h4><u>Description</u></h4>
I made this case to hold my PanelDue and Octoprint on my HEVO.  I will make other version containing different mounting or stand alone options.  If you have a request please feel free to contact me.  I made this to work with both version 2 and 3 of the PanelDue board.  This version uses brass inserts, I will try make a version that does not use the inserts.  I currently only have the 5" version completed.   I will create the other sizes latter on. 

<br>
<h4><u>To Do:</u></h4>
<ul>
<li>Add 2020 version</li>
<li>Add stand alone version</li>
<li>Add versions that do not use inserts.</li>
</ul>

<br>
<h4><u>Change Log</u></h4>
<h5>Update 12/12/2017</h5>
<ul><i>
<li>Updated pi camera cover.  The cut out was on the wrong side before.</li>
</i></ul>
<h5>Update 12/10/2017</h5>
<ul><i>
<li>Added pi case and cover.</li>
<li>Added pi camera mount</li>
</i></ul>

# Print Settings

Printer: Anet A8
Rafts: Yes
Supports: Yes
Resolution: 0.15
Infill: 20